package main

import "github.com/popsa/runner/cmd"

func main() {
	cmd.Execute()
}
