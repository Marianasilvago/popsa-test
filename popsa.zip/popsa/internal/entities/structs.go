package entities

import "time"

type Metadata struct {
	Location *LatLng
	DateInfo *DateInfo
}

// LatLng store the latitude and longitude
type LatLng struct {
	Lat float64 `json:"lat"`
	Lng float64 `json:"lng"`
}

type DateInfo struct {
	DateRaw string
	Meta    map[string]string
}

type Suggestion struct {
	FileInfo *FileInfo
	Error    error
	Titles   []TitleInfo
}

type TitleInfo struct {
	Title           string
	LocationCounter LocationCounter
	Considerations  map[string]Consideration
}

type Consideration struct {
	Key   string
	Count int
	Value string
}

type LocationCounter struct {
	Count        int
	Location     *LatLng
	DateInfoList []*DateInfo
}

type FileInfo struct {
	MetadataList []Metadata
	Name         string
	Path         string
	Signature    string
	Time         time.Time
}

type Weather struct {
	Status string `json:"status"`
	Data   struct {
		Lat     float64 `json:"lat"`
		Lng     float64 `json:"lng"`
		History []struct {
			Time                int     `json:"time"`
			Temperature         float64 `json:"temperature"`
			ApparentTemperature float64 `json:"apparentTemperature"`
			Summary             string  `json:"summary"`
			Icon                string  `json:"icon"`
			DewPoint            float64 `json:"dewPoint"`
			Humidity            float64 `json:"humidity"`
			Pressure            float64 `json:"pressure"`
			WindSpeed           float64 `json:"windSpeed"`
			WindGust            float64 `json:"windGust"`
			WindBearing         int     `json:"windBearing"`
			CloudCover          int     `json:"cloudCover"`
			Visibility          float64 `json:"visibility"`
			Ozone               float64 `json:"ozone"`
		} `json:"history"`
	} `json:"data"`
}

// Address structure used in the Geocoding and GeocodingReverse functions
// Note: The FormattedAddress field should be used only for the GeocodingReverse
// to get the formatted address from the Google Geocoding API. It is not used in
// the Geocoding function.
type Address struct {
	Street           string
	Number           int
	Neighborhood     string
	District         string
	City             string
	County           string
	State            string
	Country          string
	PostalCode       string
	FormattedAddress string
	Types            string
}

type Config struct {
	Database       *Database
	Settings       *Settings
	GOOGLE_API_KEY string
	HERE_API_KEY   string
	AMBEE_API_KEY  string
}

type Database struct {
	Host string
	DB   string
}

type Settings struct {
}
