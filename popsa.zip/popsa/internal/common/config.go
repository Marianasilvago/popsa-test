package common

import "github.com/popsa/internal/entities"

func GetDefaultConfig() *entities.Config {
	return &entities.Config{
		GOOGLE_API_KEY: `AIzaSyA181-MAfGU40UHY3DMEdQLebK18ahT2Ug`, //put your API-KEY
		HERE_API_KEY:   `3UCfBhok8rSUHavexbou`,
		AMBEE_API_KEY:  `2cfb988ecddf879c4d376479e9d05fe1f4ef87ea9b609a3e29f0de3276d4dfe7`,
	}
}
