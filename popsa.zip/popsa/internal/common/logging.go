package common

import (
	"io"

	"github.com/sirupsen/logrus"
)

func GetDefaultLogger(f io.Writer) *logrus.Logger {

	// Create a new instance of the logger. You can have any number of instances.
	log := logrus.New()

	log.SetOutput(f) //os.Stdout
	// Log as JSON instead of the default ASCII formatter.
	log.SetFormatter(&logrus.JSONFormatter{})
	log.SetReportCaller(true)
	return log
}
