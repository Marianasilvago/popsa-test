package here

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"

	"github.com/parnurzeal/gorequest"
	"github.com/popsa/internal/entities"
)

// Define the Geocode API key, URL as a constant
const (
	ApiUrl = "https://revgeocode.search.hereapi.com/v1/revgeocode?"
)

type Results struct {
	Items []struct {
		Title string `json:"title"`
	} `json:"items"`
}

func GetReverseGeocoding(agent *gorequest.SuperAgent) (*entities.Address, error) {
	// Send the HTTP request and get the results
	results, err := httpRequest(agent)
	if err != nil {
		return nil, err
	}

	// Convert the results to an Address slice called addresses
	return convertResultsToAddress(results)
}

func httpRequest(agent *gorequest.SuperAgent) (*Results, error) {
	// Send the request via a client
	// Do sends an HTTP request and returns an HTTP response
	resp, bodyBytes, errs := agent.EndBytes()
	if errs != nil {
		return nil, fmt.Errorf("error %v", errs)
	}

	// Callers should close resp.Body when done reading from it
	// Defer the closing of the body
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, errors.New(string(bodyBytes))
	}

	results := Results{}
	// Use json.Decode for reading streams of JSON data
	err := json.NewDecoder(resp.Body).Decode(&results)
	if err != nil {
		return nil, err
	}

	return &results, nil

}

func convertResultsToAddress(result *Results) (*entities.Address, error) {
	//TODO
	return nil, nil
}
