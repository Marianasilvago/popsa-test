package geo

import (
	"net/http"
	"strconv"
	"sync/atomic"
	"time"

	"github.com/parnurzeal/gorequest"
	"github.com/popsa/internal/entities"
	"github.com/popsa/internal/partners/geo/google"
	"github.com/popsa/internal/partners/geo/here"
)

const (
	GOOGLE = "google"
	HERE   = "here"
)

var (
	partnerUptime = map[string]*UptimeStats{
		GOOGLE: {
			success: 0,
			hits:    0,
		},
		HERE: {
			success: 0,
			hits:    0,
		},
	}
)

type UptimeStats struct {
	success int64
	hits    int64
}

func (u *UptimeStats) update(isSuccess bool) {
	atomic.AddInt64(&u.hits, 1)
	if isSuccess {
		atomic.AddInt64(&u.success, 1)
	}
}
func (u *UptimeStats) successRatio() float64 {
	hits := atomic.LoadInt64(&u.hits)
	succcess := atomic.LoadInt64(&u.success)

	return float64(succcess) / float64(hits)
}

// GeocodingReverse function is used to convert a Location structure
// to an Address structure
func GeocodingReverse(location *entities.LatLng, googleApiKey, hereApiKey string) (*entities.Address, error) {

	var address *entities.Address
	var err error

	//check cache for success stats about the external partners
	//select google or Here based on the previous stats
	googleVal := partnerUptime[GOOGLE]
	hereVal := partnerUptime[HERE]

	if googleVal.successRatio() >= hereVal.successRatio() {
		address, err = google.GetReverseGeocoding(getURLGeocodingReverse(location, google.ApiUrl, googleApiKey))
		googleVal.update(err == nil)
		//we can implement fallback mechanism like try HERE incase of google api not responding
	} else {
		address, err = here.GetReverseGeocoding(getURLGeocodingReverse(location, here.ApiUrl, hereApiKey))
		hereVal.update(err == nil)
	}
	return address, err
}

func getURLGeocodingReverse(location *entities.LatLng, apiUrl, apiKey string) *gorequest.SuperAgent {
	// Convert the latitude and longitude from double to string
	latitude := strconv.FormatFloat(location.Lat, 'f', 8, 64)
	longitude := strconv.FormatFloat(location.Lng, 'f', 8, 64)

	// Create the URL based on latitude and longitude
	url := apiUrl + "latlng=" + latitude + "," + longitude

	// Use the API key if it was set
	if apiKey != "" {
		url += "&key=" + apiKey
	}

	//create superagent with timeouts and retry mechanism for network failure
	return gorequest.New().
		Timeout(time.Second*15).
		Get(url).
		Retry(2, 5*time.Second, http.StatusServiceUnavailable, http.StatusRequestTimeout)
}
