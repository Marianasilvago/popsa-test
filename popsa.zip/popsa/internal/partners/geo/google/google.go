package google

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"

	"github.com/parnurzeal/gorequest"
	"github.com/popsa/internal/entities"
)

// Define the Geocode API key, URL as a constant
const (
	ApiUrl = "https://maps.googleapis.com/maps/api/geocode/json?"
)

type Results struct {
	Results []Result `json:"results"`
	Status  string   `json:"status"`
}

// Result store each result from the JSON
type Result struct {
	AddressComponents []Address `json:"address_components"`
	FormattedAddress  string    `json:"formatted_address"`
	Geometry          Geometry  `json:"geometry"`
	PlaceId           string    `json:"place_id"`
	Types             []string  `json:"types"`
}

// Address store each address is identified by the 'types'
type Address struct {
	LongName  string   `json:"long_name"`
	ShortName string   `json:"short_name"`
	Types     []string `json:"types"`
}

// Geometry store each value in the geometry
type Geometry struct {
	Bounds       Bounds `json:"bounds"`
	Location     LatLng `json:"location"`
	LocationType string `json:"location_type"`
	Viewport     Bounds `json:"viewport"`
}

// Bounds Northeast and Southwest
type Bounds struct {
	Northeast LatLng `json:"northeast"`
	Southwest LatLng `json:"southwest"`
}

// LatLng store the latitude and longitude
type LatLng struct {
	Lat float64 `json:"lat"`
	Lng float64 `json:"lng"`
}

func GetReverseGeocoding(agent *gorequest.SuperAgent) (*entities.Address, error) {
	// Send the HTTP request and get the results
	results, err := httpRequest(agent)
	if err != nil {
		return nil, err
	}

	// Convert the results to an Address slice called addresses
	return convertResultsToAddress(results), nil
}

func httpRequest(agent *gorequest.SuperAgent) (*Results, error) {
	// Send the request via a client
	// Do sends an HTTP request and returns an HTTP response
	resp, bodyBytes, errs := agent.EndBytes()
	if errs != nil {
		return nil, fmt.Errorf("error %v", errs)
	}

	// Callers should close resp.Body when done reading from it
	// Defer the closing of the body
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, errors.New(string(bodyBytes))
	}

	results := Results{}
	// Use json.Decode for reading streams of JSON data
	err := json.NewDecoder(resp.Body).Decode(&results)
	if err != nil {
		return nil, err
	}

	// The "OK" status indicates that no error has occurred, it means
	// the address was analyzed and at least one geographic code was returned
	if strings.ToUpper(results.Status) != "OK" {
		// If the status is not "OK" check what status was returned
		switch strings.ToUpper(results.Status) {
		case "ZERO_RESULTS":
			err = errors.New("No results found.")
			break
		case "OVER_QUERY_LIMIT":
			err = errors.New("You are over your quota.")
			break
		case "REQUEST_DENIED":
			err = errors.New("Your request was denied.")
			break
		case "INVALID_REQUEST":
			err = errors.New("Probably the query is missing.")
			break
		case "UNKNOWN_ERROR":
			err = errors.New("Server error. Please, try again.")
			break
		default:
			break
		}
	}

	return &results, err
}

// Convert a structs.Results to a slice of Address structures
func convertResultsToAddress(results *Results) *entities.Address {

	for index := 0; index < len(results.Results); index++ {
		var address *entities.Address

		// Put each component from the AddressComponents slice in the correct field in the Address structure
		for _, component := range results.Results[index].AddressComponents {
			// Check all types of each component
			for _, types := range component.Types {
				switch types {
				case "route":
					address.Street = component.LongName
					break
				case "street_number":
					address.Number, _ = strconv.Atoi(component.LongName)
					break
				case "neighborhood":
					address.Neighborhood = component.LongName
					break
				case "sublocality":
					address.District = component.LongName
					break
				case "sublocality_level_1":
					address.District = component.LongName
					break
				case "locality":
					address.City = component.LongName
					break
				case "administrative_area_level_3":
					address.City = component.LongName
					break
				case "administrative_area_level_2":
					address.County = component.LongName
					break
				case "administrative_area_level_1":
					address.State = component.LongName
					break
				case "country":
					address.Country = component.LongName
					break
				case "postal_code":
					address.PostalCode = component.LongName
					break
				default:
					break
				}
			}
		}

		address.FormattedAddress = results.Results[index].FormattedAddress
		address.Types = results.Results[index].Types[0]

		return address
	}
	return nil
}
