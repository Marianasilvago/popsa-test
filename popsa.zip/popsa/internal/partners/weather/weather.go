package weather

import (
	"net/http"
	"strconv"
	"time"

	"github.com/parnurzeal/gorequest"
	"github.com/popsa/internal/entities"
	"github.com/popsa/internal/partners/weather/ambee"
)

func GetHistoricalData(location *entities.LatLng, from, to, apiKey string) (*entities.Weather, error) {
	// Convert the latitude and longitude from double to string
	latitude := strconv.FormatFloat(location.Lat, 'f', 8, 64)
	longitude := strconv.FormatFloat(location.Lng, 'f', 8, 64)

	// Create the URL based on latitude and longitude
	url := ambee.ApiURL + "lat=" + latitude + "&lng=" + longitude + "&from=" + from + "&to=" + to

	//create superagent with timeouts and retry mechanism for network failure
	req := gorequest.New().
		Timeout(time.Second*15).
		Get(url).
		Retry(2, 5*time.Second, http.StatusServiceUnavailable, http.StatusRequestTimeout)

	return ambee.GetHistoricalData(req, apiKey)
}
