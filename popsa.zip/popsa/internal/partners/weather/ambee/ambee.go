package ambee

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/http"

	"github.com/parnurzeal/gorequest"
	"github.com/popsa/internal/entities"
)

const (
	ApiURL = `https://api.ambeedata.com/weather/history/by-lat-lng`
)

func GetHistoricalData(agent *gorequest.SuperAgent, apiKey string) (*entities.Weather, error) {
	return httpRequest(agent, apiKey)
}

func httpRequest(agent *gorequest.SuperAgent, apiKey string) (*entities.Weather, error) {
	resp, bodyBytes, errs := agent.Set("x-api-key", apiKey).
		Set("Content-type", "application/json").EndBytes()
	if errs != nil {
		return nil, fmt.Errorf("error %v", errs)
	}
	// Callers should close resp.Body when done reading from it
	// Defer the closing of the body
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, errors.New(string(bodyBytes))
	}

	results := entities.Weather{}
	// Use json.Decode for reading streams of JSON data
	err := json.NewDecoder(resp.Body).Decode(&results)
	if err != nil {
		return nil, err
	}

	return &results, nil
}
