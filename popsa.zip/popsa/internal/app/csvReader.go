package app

import (
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"io"
	"os"
	"path"
	"strconv"
	"time"

	"github.com/nleeper/goment"
	"github.com/popsa/internal/entities"
)

func (app *App) ParseFileInfo(filePath string) (*entities.FileInfo, error) {

	sign, err := getSignature(filePath)
	if err != nil {
		return nil, err
	}

	result := new(entities.FileInfo)
	result.Time = time.Now()
	result.Signature = sign
	result.Path = filePath
	result.Name = path.Base(filePath)
	metadataList, err := ParseMetadataList(filePath)
	if err != nil {
		return result, err
	}
	result.MetadataList = metadataList
	return result, nil
}
func getSignature(filePath string) (string, error) {
	f, err := os.Open(filePath)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return "", err
	}

	return hex.EncodeToString(h.Sum(nil)), nil
}
func ParseMetadataList(filePath string) ([]entities.Metadata, error) {
	reader, err := os.Open(filePath)
	if err != nil {
		return nil, err
	}
	defer reader.Close()

	result := make([]entities.Metadata, 0)
	csvr := csv.NewReader(reader)
	for {
		row, err := csvr.Read()
		if err != nil {
			if err == io.EOF {
				err = nil
			}
			return result, err
		}

		loc := new(entities.LatLng)
		if loc.Lat, err = strconv.ParseFloat(row[1], 64); err != nil {
			return result, err
		}
		if loc.Lng, err = strconv.ParseFloat(row[2], 64); err != nil {
			return result, err
		}

		dateInfo, err := getDateInfo(row[0])
		if err != nil {
			return result, err
		}
		result = append(result, entities.Metadata{
			Location: loc,
			DateInfo: dateInfo,
		})
	}
}

func getDateInfo(date string) (*entities.DateInfo, error) {

	g, err := goment.New(date)
	// t, err := time.Parse("2006-01-02 15:04:05", row[0])
	if err != nil {
		return nil, err
	}
	result := &entities.DateInfo{
		DateRaw: date,
		Meta:    make(map[string]string),
	}

	result.Meta["fromNow"] = g.FromNow()
	result.Meta["year"] = strconv.Itoa(g.Year())
	if g.ISOWeekday() >= 6 {
		result.Meta["weektype"] = "Weekend"
	} else {
		result.Meta["weektype"] = "Weekday"
	}
	hr := g.Get("hour")
	if hr <= 5 {
		result.Meta["moment"] = "Mid-Night"
	} else if hr > 5 && hr <= 12 {
		result.Meta["moment"] = "Morning"
	} else if hr > 12 && hr <= 16 {
		result.Meta["moment"] = "Noon"
	} else if hr > 16 && hr <= 20 {
		result.Meta["moment"] = "Evening"
	} else {
		result.Meta["moment"] = "Night"
	}

	if time.Now().Year()-g.Year() > 1 {
		result.Meta["keyword"] = "Throwback"
	} else {
		result.Meta["keyword"] = "Recent"
	}
	m := g.Month()

	if m <= 2 || m > 11 {
		if m == 2 && g.Date() == 14 {
			result.Meta["occasion"] = "Valentines day"
		}
		result.Meta["season"] = "Winter"
	} else if m > 2 && m <= 5 {
		result.Meta["season"] = "Summer"
	} else if m > 5 && m <= 8 {
		result.Meta["season"] = "Monsoon"
	} else if m > 8 && m <= 10 {
		result.Meta["season"] = "Fall"
	} else if m == 12 {
		d := g.Date()
		if d >= 23 && d <= 25 {
			result.Meta["occasion"] = "Christmas"
		}
		if d == 31 {
			result.Meta["occasion"] = "Newyear eve"
		}
	}

	return result, nil

}
