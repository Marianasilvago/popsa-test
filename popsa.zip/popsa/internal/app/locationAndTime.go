package app

import (
	"fmt"
	"sort"
	"time"

	"github.com/popsa/internal/entities"
	"github.com/popsa/internal/partners/geo"
	"github.com/popsa/internal/partners/weather"
	"github.com/sirupsen/logrus"
)

func (app *App) getTopTitlesByLocationAndTime(metaList []entities.Metadata) []entities.TitleInfo {
	result := make(map[string]entities.LocationCounter, 0)
	totalCount := len(metaList)
	for _, metadata := range metaList {
		loc := locationString(metadata.Location)
		count := 1
		dInfo := []*entities.DateInfo{metadata.DateInfo}

		if val, ok := result[loc]; ok {
			count = val.Count + 1
			dInfo = append(val.DateInfoList, metadata.DateInfo)
		}
		result[loc] = entities.LocationCounter{
			Count:        count,
			Location:     metadata.Location,
			DateInfoList: dInfo,
		}
	}
	resp := make([]entities.LocationCounter, 0)

	for _, val := range result {
		resp = append(resp, val)
	}
	//sort the response based on the count
	sort.Slice(resp[:], func(i, j int) bool {
		return resp[i].Count > resp[j].Count
	})

	titleInfoList, globalConsideration := app.aggregateData(resp, totalCount)
	//add title based on global metadata as well
	titleInfoList = append(titleInfoList, entities.TitleInfo{
		Considerations: globalConsideration,
	})

	return titleInfoList
}

func locationString(loc *entities.LatLng) string {
	//consider only two decimal digits for better aggregation
	return fmt.Sprintf("%.2f,%.2f", loc.Lat, loc.Lng)
}

func (app *App) aggregateData(input []entities.LocationCounter, totalCount int) ([]entities.TitleInfo, map[string]entities.Consideration) {
	processingCount := 0
	globalConsideration := make(map[string]entities.Consideration, 0)
	result := make([]entities.TitleInfo, 0)
	index := 0
	//process and consider more than half locations but not all
	for ; index < len(input) && processingCount <= (totalCount/2); index++ {
		val := input[index]
		localConsideration := make(map[string]entities.Consideration, 0)
		processingCount = processingCount + val.Count
		for _, d := range val.DateInfoList {
			for key, meta := range d.Meta {
				if v, ok := localConsideration[meta]; ok {
					v.Count = v.Count + 1
					localConsideration[meta] = v
				} else {
					localConsideration[meta] = entities.Consideration{
						Count: 1,
						Key:   key,
						Value: meta,
					}
				}
				if v, ok := globalConsideration[meta]; ok {
					v.Count = v.Count + 1
					globalConsideration[meta] = v
				} else {
					globalConsideration[meta] = entities.Consideration{
						Count: 1,
						Key:   key,
						Value: meta,
					}
				}
			}
		}
		result = append(result, entities.TitleInfo{
			LocationCounter: val,
			Considerations:  localConsideration,
		})
	}

	app._logger.WithFields(logrus.Fields{
		"totalcount":      (totalCount),
		"processingCount": processingCount,
		"inputlen":        len(input),
		"index":           index,
	}).Debugln("Aggregate func stats")
	return result, globalConsideration
}

func (app *App) processTitleInfoWithLocationAndTime(inputList []entities.TitleInfo) ([]entities.TitleInfo, error) {
	numJobs := len(inputList)
	jobs := make(chan entities.TitleInfo, numJobs)
	results := make(chan entities.TitleInfo, numJobs)

	app._logger.WithFields(logrus.Fields{
		"inputlen": len(inputList),
		"numJobs":  numJobs,
	}).Debugln("processTitleInfoWithLocationAndTime starts")
	for w := 1; w <= app._workers; w++ {
		go app.workerProcessTitleInfo(w, jobs, results)
	}

	for jobId := 0; jobId < numJobs; jobId++ {
		jobs <- inputList[jobId]
	}
	defer close(jobs)
	app._logger.WithFields(logrus.Fields{
		"inputlen": len(inputList),
		"numJobs":  numJobs,
	}).Debugln("processTitleInfoWithLocationAndTime waiting for result")
	result := make([]entities.TitleInfo, 0)
	a := 0
	for ; a < numJobs; a++ {
		result = append(result, <-results)
	}

	app._logger.WithFields(logrus.Fields{
		"recieved": a,
		"sent":     numJobs,
	}).Debugln("processTitleInfoWithLocationAndTime completed")

	return result, nil
}

func (app *App) workerProcessTitleInfo(id int, jobs <-chan entities.TitleInfo, results chan<- entities.TitleInfo) {

	for job := range jobs {
		updateConsiderations := func(key, val string) {
			if v, ok := job.Considerations[val]; ok {
				v.Count = v.Count + 1
				job.Considerations[val] = v
			} else {
				job.Considerations[val] = entities.Consideration{
					Count: 1,
					Key:   key,
					Value: val,
				}
			}
		}
		if job.LocationCounter.Location != nil {
			//location specific
			app._logger.WithFields(logrus.Fields{
				"location": job.LocationCounter.Location,
			}).Debugln("fetch geo location addr")

			addr, err := geo.GeocodingReverse(job.LocationCounter.Location,
				app._config.GOOGLE_API_KEY, app._config.HERE_API_KEY)
			if err == nil && addr != nil {

				app._logger.WithFields(logrus.Fields{
					"location": job.LocationCounter.Location,
					"address":  addr,
				}).Debugln("fetch geo location success")
				updateConsiderations("country", addr.Country)
				updateConsiderations("state", addr.State)
				updateConsiderations("street", addr.Street)
				updateConsiderations("city", addr.City)
				updateConsiderations("neighborhood", addr.Neighborhood)
			}

			app._logger.WithFields(logrus.Fields{
				"location": job.LocationCounter.Location,
			}).Errorf("error %v", err)

			//add other location + datetime combo internet search and get details like
			//wheather, festives, events, sports, public gatherings, city news for better considerations
			for _, dateVal := range job.LocationCounter.DateInfoList {
				t, err := time.Parse("2006-01-02 15:04:05", dateVal.DateRaw)
				if err == nil {
					nextDay := t.Add(time.Hour * 24)

					app._logger.WithFields(logrus.Fields{
						"location": job.LocationCounter.Location,
						"from":     dateVal.DateRaw,
						"to":       nextDay.Format("2006-01-02 15:04:05"),
					}).Debugln("fetch historical weather data")
					weather, err := weather.GetHistoricalData(job.LocationCounter.Location,
						dateVal.DateRaw, nextDay.Format("2006-01-02 15:04:05"), app._config.AMBEE_API_KEY)
					if err == nil && weather != nil {

						app._logger.WithFields(logrus.Fields{
							"location": job.LocationCounter.Location,
							"from":     dateVal.DateRaw,
							"to":       nextDay.Format("2006-01-02 15:04:05"),
							"weather":  weather,
						}).Debugln("successfully fetched historical weather data")
						for _, historydata := range weather.Data.History {
							updateConsiderations("weather-summary", historydata.Summary)
							updateConsiderations("weather", historydata.Icon)
						}
					}
					app._logger.WithFields(logrus.Fields{
						"location": job.LocationCounter.Location,
						"from":     dateVal.DateRaw,
						"to":       nextDay.Format("2006-01-02 15:04:05"),
					}).Errorln("GetHistoricalData err", err)
				}
			}

			//TODO:: festives, events, sports, public gatherings, city news for better considerations
		}

		results <- entities.TitleInfo{
			Title:           "", //TODO::
			LocationCounter: job.LocationCounter,
			Considerations:  job.Considerations,
		}
	}
}
