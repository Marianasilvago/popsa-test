package app

import (
	"errors"
	"path"
	"strings"

	"github.com/popsa/internal/entities"
	"github.com/sirupsen/logrus"
)

type App struct {
	_config  *entities.Config
	_workers int
	_logger  *logrus.Logger
}

func NewApp(c *entities.Config, workerCount int, logger *logrus.Logger) *App {
	return &App{
		_config:  c,
		_workers: workerCount,
		_logger:  logger,
	}
}

func (app *App) SuggestTitles(filePaths []string) ([]entities.Suggestion, error) {
	if len(filePaths) == 0 {
		return nil, errors.New("invalid filePaths")
	}

	var _errs []string

	result := make([]entities.Suggestion, 0)
	for _, filePath := range filePaths {
		fileInfo, err := app.ParseFileInfo(filePath)
		if err != nil {
			_errs = append(_errs, "failed to parse file: "+filePath)
			if fileInfo == nil {
				fileInfo = &entities.FileInfo{
					Path: filePath,
					Name: path.Base(filePath),
				}
			}
			result = append(result, entities.Suggestion{
				FileInfo: fileInfo,
				Error:    err,
			})
			//if error occurs then continue to the next file
			continue
		}
		suggestion, err := app.process(fileInfo)
		if err != nil {
			_errs = append(_errs, "failed to process file: "+filePath)
		}

		result = append(result, *suggestion)

	}

	if len(_errs) > 0 {
		return result, errors.New(strings.Join(_errs, "\n"))
	}
	return result, nil
}

func (app *App) process(fileInfo *entities.FileInfo) (*entities.Suggestion, error) {
	result := &entities.Suggestion{FileInfo: fileInfo}
	if fileInfo == nil {
		err := errors.New("bad input fileInfo")
		result.Error = err
		return result, err
	}
	//Check storage for fileinfo.Signature status. Result will be one of the following
	//1.Doesn't exists then process from start
	//2.Exists and was completed then get the cached result
	//3.Exists but was not completed then get the cached intermediate result and resume operation
	//The above strategy will help us optimize our application performance and make sense when large
	//inputs are provided and one of our external dependencies was not available

	//get titles based on location & its dateinfo metadata
	titleInfoList := app.getTopTitlesByLocationAndTime(fileInfo.MetadataList)
	//add it to the result
	result.Titles = titleInfoList

	processedTitleInfoList, err := app.processTitleInfoWithLocationAndTime(titleInfoList)
	if err != nil {
		result.Error = err
		return result, err
	}
	//update it to the result
	result.Titles = processedTitleInfoList
	return result, nil
}
