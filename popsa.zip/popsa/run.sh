
go build -o artifacts/popsa

pushd artifacts
 ./popsa version
 ./popsa title /Users/stackbuilders/github.com/popsa/artifacts/1.csv
 ./popsa title /Users/stackbuilders/github.com/popsa/artifacts/2.csv /Users/stackbuilders/github.com/popsa/artifacts/3.csv
 popd

