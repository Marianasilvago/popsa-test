package cmd

import (
	"fmt"
	"os"

	"github.com/popsa/internal/app"
	"github.com/popsa/internal/common"
	"github.com/spf13/cobra"
)

var (
	// Used for flags.
	cfgFile     string
	userLicense string

	rootCmd = &cobra.Command{
		Use:   "popsa",
		Short: "Suggest title/titles for Album Applications",
		Long:  `Popsa application is used to predict titles for a group of photos or albums`,
	}
)

// Execute executes the root command.
func Execute() error {
	return rootCmd.Execute()
}

func init() {

	rootCmd.PersistentFlags().StringVar(&cfgFile, "config", "", "config file (default is $HOME/.cobra.yaml)")
	rootCmd.PersistentFlags().StringP("author", "a", "developer", "author name for copyright attribution")
	rootCmd.PersistentFlags().StringVarP(&userLicense, "license", "l", "", "name of license for the project")

	rootCmd.AddCommand(versionCmd)
	rootCmd.AddCommand(suggestTitleCmd)
}

var versionCmd = &cobra.Command{
	Use:   "version",
	Short: "Print the version number of Popsa",
	Long:  `All software has versions. This is Popsa's`,
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("Popsa v0.9 -- HEAD")
	},
}

var suggestTitleCmd = &cobra.Command{
	Use:   "title",
	Short: "Print the title/titles suggestions for a given csv input",
	Long:  `Print the title/titles suggestions for a given csv input`,
	Run: func(cmd *cobra.Command, args []string) {
		if len(args) < 1 {
			fmt.Println("Error: requires a valid input filePath argument")
			return
		}
		for _, filePath := range args {
			exists, err := exists(filePath)
			if err != nil {
				fmt.Printf("Error: %v\n", err)
				return
			}

			if !exists {
				fmt.Println("Error: provide valid existing CSV filePath")
				return
			}
		}

		// Output to stdout instead of the default stderr
		// Can be any io.Writer
		// open a file
		f, err := os.OpenFile("output.log", os.O_APPEND|os.O_CREATE|os.O_RDWR, 0666)
		if err != nil {
			fmt.Printf("error opening file: %v", err)
		}
		// don't forget to close it
		defer f.Close()

		application := app.NewApp(common.GetDefaultConfig(), 10, common.GetDefaultLogger(f))
		suggestions, err := application.SuggestTitles(args)
		if err != nil {
			fmt.Printf("Error: %v\n", err)
		}
		for _, sugg := range suggestions {
			if sugg.FileInfo != nil {
				fmt.Printf("%v:\n", sugg.FileInfo.Name)
			}
			if sugg.Error != nil {
				fmt.Printf("\t - Error: %v\n", sugg.Error)
			}

			for _, title := range sugg.Titles {
				if title.LocationCounter.Count > 0 {
					fmt.Printf("\t - %d input record with same location\n", title.LocationCounter.Count)
				}
				for _, val := range title.Considerations {
					fmt.Printf("\t - %d %s:%s\n", val.Count, val.Key, val.Value)
				}
			}
		}
	},
}

// exists returns whether the given file or directory exists
func exists(path string) (bool, error) {
	_, err := os.Stat(path)
	if err == nil {
		return true, nil
	}
	if os.IsNotExist(err) {
		return false, nil
	}
	return false, err
}
